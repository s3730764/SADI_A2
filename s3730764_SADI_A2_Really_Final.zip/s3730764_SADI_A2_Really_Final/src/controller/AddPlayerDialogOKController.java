package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import model.file.GameLoader;
import model.file.GameLoaderException;
import model.interfaces.GameEngine;
import model.interfaces.Player;
import view.AddPlayerDialogBox;
import view.model.ViewModel;

//Listens to the OK button on the AddPlayerDialogBox
public class AddPlayerDialogOKController implements ActionListener
{
	private AddPlayerDialogBox dialog;
	private GameEngine gameEngine;
	private GameLoader gameLoader;
	private ViewModel viewModel;

	public AddPlayerDialogOKController(AddPlayerDialogBox dialog, GameEngine gameEngine, 
			GameLoader gameLoader, ViewModel viewModel) 
	{
		this.dialog = dialog;
		this.gameEngine = gameEngine;
		this.gameLoader = gameLoader;
		this.viewModel = viewModel;
	}

	@Override
	public void actionPerformed(ActionEvent event) 
	{
		Player player = dialog.getPlayer();
		gameEngine.addPlayer(player);
		
		try 
		{
			gameLoader.appendPlayer(gameLoader.getPath(), player);
			viewModel.playerAdded(player);

		} catch (GameLoaderException e) 
		{
			e.printStackTrace();
		}
		
		dialog.dispose();
		
	}

}
