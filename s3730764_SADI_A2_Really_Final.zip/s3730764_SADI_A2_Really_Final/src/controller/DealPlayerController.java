package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import model.file.GameLoader;
import model.interfaces.GameEngine;
import model.interfaces.Player;
import view.MainFrame;
import view.model.ViewModel;

//Listens to the Deal button and menu item. Checks pre-conditions before dealing.
public class DealPlayerController implements ActionListener
{
	private final int DELAY = 1200;
	private GameEngine gameEngine;
	private ViewModel viewModel;
	private MainFrame frame;
	private GameLoader gameLoader;
	
	public DealPlayerController(ViewModel viewModel, GameEngine gameEngine, 
			MainFrame frame, GameLoader gameLoader) 
	{
		this.gameEngine = gameEngine;
		this.viewModel = viewModel;
		this.frame = frame;
		this.gameLoader = gameLoader;
	}

	@Override
	public void actionPerformed(ActionEvent event) 
	{	
		//If no players in game, prompt user to add one
		if (gameEngine.getAllPlayers().size() == 0)
			frame.promptAddPlayerDialog(gameLoader);
		
		Player player = viewModel.getSelectedPlayer();
		int numOfPlayers = gameEngine.getAllPlayers().size();
				
		//At end of game, no player selected, so button is disabled
		if (player == null)
			return;
		
		if (numOfPlayers > 0)
		{
			//Check player has not already been dealt
			if (player.getResult() > 0)
			{
				String message = player.getPlayerName() + " has already been dealt";
				frame.displayMessageDialog(message);
				return;
			}
			
			//If player has not bet, prompt user to bet
			if (player.getBet() == 0)
			{
				String message = "Player must bet before being dealt.\nPlace bet then deal?";
				int optionPaneOutcome = frame.displayConfirmDialog(message);
				if (optionPaneOutcome == JOptionPane.YES_OPTION)
					frame.displayBetDialog();
			}
			
			//Deal once pre-conditions checked
			if (player.getBet() > 0)
			{
				new Thread()
				{
					@Override
					public void run()
					{	
						gameEngine.dealPlayer(player, DELAY);
						if (viewModel.allPlayersPlayed())
							gameEngine.dealHouse(DELAY);		
					}
				}.start();
			}
			
		}
		
	}
}
