package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import view.MainFrame;
import view.model.ViewModel;

//Listens to the New Game button and menu item
public class NewGameController implements ActionListener 
{
	private ViewModel viewModel;
	private MainFrame frame;
	
	public NewGameController(ViewModel viewModel, MainFrame frame)
	{
		this.viewModel = viewModel;
		this.frame = frame;
	}

	@Override
	public void actionPerformed(ActionEvent event) 
	{
		//If game not finished, confirm that user actually wants a new game
		if (!viewModel.allPlayersPlayed())
		{
			int optionPaneOutcome = JOptionPane.showConfirmDialog(frame, 
					"Do you really want to start a new game?");
			if (optionPaneOutcome == JOptionPane.NO_OPTION)
				return;
			if (optionPaneOutcome == JOptionPane.CANCEL_OPTION)
				return;
		}
		
		viewModel.newGame();
	}

}
