package controller;

import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

//Listens to the Cancel button on the AddPlayerDialogBox and BetDialogBox
public class CancelButtonController implements ActionListener 
{
	private Window window;
	
	public CancelButtonController(Window window)
	{
		this.window = window;
	}

	@Override
	public void actionPerformed(ActionEvent event) 
	{
		window.dispose();
	}

}
