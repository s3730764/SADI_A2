package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import model.file.GameLoader;
import model.interfaces.Player;
import view.MainFrame;
import view.model.ViewModel;

//Listens to the Place Bet button and menu item. 
//Creates relevant dialog if no players present or player has already bet.
public class BetController implements ActionListener
{
	private MainFrame frame;
	private ViewModel viewModel;
	private GameLoader gameLoader;
	
	public BetController(MainFrame frame, ViewModel viewModel, GameLoader gameLoader)
	{
		this.frame = frame;
		this.viewModel = viewModel;
		this.gameLoader = gameLoader;
	}


	@Override
	public void actionPerformed(ActionEvent event) 
	{
		//Prompt user to add a player if none in game
		int numOfPlayers = viewModel.getPlayerArrayList().size();
		if (numOfPlayers == 0)
			frame.promptAddPlayerDialog(gameLoader);
		
		//Check pre-conditions before opening bet dialog box
		Player player = viewModel.getSelectedPlayer();
		String playerName = player != null ? player.getPlayerName() : null;
		String errorMessage = playerName + " has already bet";


		if (player != null)
			if (numOfPlayers != 0)
				if (player.getBet() > 0)
					frame.displayMessageDialog(errorMessage);
				else if (viewModel.allPlayersPlayed())
					frame.displayMessageDialog(errorMessage);
				else
					frame.displayBetDialog();
			
	}
	

}
