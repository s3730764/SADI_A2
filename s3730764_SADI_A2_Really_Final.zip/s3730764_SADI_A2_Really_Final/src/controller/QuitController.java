package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.util.Collection;

import model.file.GameLoader;
import model.file.GameLoaderException;
import model.interfaces.GameEngine;
import model.interfaces.Player;
import view.MainFrame;

//Listens to the Quit menu item and MainFrame
public class QuitController extends WindowAdapter implements WindowListener, ActionListener
{
	private GameLoader gameLoader;
	private MainFrame frame;
	private GameEngine gameEngine;
	
	public QuitController(GameLoader gameLoader, GameEngine gameEngine, MainFrame frame)
	{
		this.gameLoader = gameLoader;
		this.gameEngine = gameEngine;
		this.frame = frame;
	}

	@Override //When "Quit" selected in Menu
	public void actionPerformed(ActionEvent event) 
	{
		saveAndClose();
	}
	
	@Override //When window is closed
	public void windowClosing(WindowEvent arg0) 
	{
		saveAndClose();
	}

	private void saveAndClose() 
	{
		String path = gameLoader.getPath();
		Collection<Player> players = gameEngine.getAllPlayers();
		
		try 
		{
			gameLoader.saveAllPlayers(path, players);
		} catch (GameLoaderException e) 
		{
			e.printStackTrace();
		}

		frame.quit();
	}

}
