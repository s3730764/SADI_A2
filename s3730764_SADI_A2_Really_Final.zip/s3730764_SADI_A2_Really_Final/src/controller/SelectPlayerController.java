package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JComboBox;
import javax.swing.JMenuItem;

import model.interfaces.Player;
import view.PlayerComboBox;
import view.model.PlayerView;
import view.model.ViewModel;

//Listens to the combo box and Select Player menu item.
public class SelectPlayerController implements ActionListener
{
	private ViewModel viewModel;
	private PlayerComboBox comboBox;
	
	public SelectPlayerController(PlayerComboBox comboBox, ViewModel viewModel)
	{
		this.comboBox = comboBox;
		this.viewModel = viewModel;
	}


	@Override
	public void actionPerformed(ActionEvent event) 
	{	
		Object source = event.getSource();
				
		//If player selected in the combo box
		if (source instanceof JComboBox)
		{
			int selectedIndex = ((PlayerComboBox) source).getSelectedIndex();
			PlayerView playerView = ((PlayerComboBox) source).getModel().getElementAt(selectedIndex);
			viewModel.playerSelected(playerView);
			return;
		}
		
		//If player selected via the menu
		if (source instanceof JMenuItem)
		{
			String menuItemText = ((JMenuItem) source).getText();
			Player player = null;
			
			for (Player storedPlayer : viewModel.getPlayerArrayList())
			{
				String storedName = storedPlayer.getPlayerName();
				
				player = storedName.equals(menuItemText) ? storedPlayer : null;
				if (player != null) break;
			}
				
			viewModel.playerSelected(player);
			
			comboBox.setSelectedItem(player);
		}

	}

}
