package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Collection;

import javax.swing.JOptionPane;

import model.interfaces.GameEngine;
import model.interfaces.Player;
import model.interfaces.PlayingCard;
import view.MainFrame;
import view.model.ViewModel;

//Listens to the Remove Player menu item. Checks pre-conditions before removing selected player.
public class RemovePlayerController implements ActionListener 
{
	private GameEngine gameEngine;
	private ViewModel viewModel;
	private MainFrame frame;

	public RemovePlayerController(GameEngine gameEngine, ViewModel viewModel, MainFrame frame) 
	{
		this.gameEngine = gameEngine;
		this.viewModel = viewModel;
		this.frame = frame;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) 
	{
		String message;
		
		//Error message if no players in the game
		int numOfPlayers = viewModel.getPlayerArrayList().size();
		if (numOfPlayers == 0)
		{
			message = "There are no players to remove!";
			frame.displayMessageDialog(message);
			return;
		}
				
		//Prevent players being removed during the game
		boolean gameInProgress = false;
		for (Player storedPlayer : gameEngine.getAllPlayers())
		{
			Collection<PlayingCard> hand = viewModel.getPreviousCards(storedPlayer);
			if (!hand.isEmpty())
				gameInProgress = true;
		}
			
		if (gameInProgress)
		{
			message = "Players cannot be removed while the game is in progress.\n"
					+ "Select 'New Game' to unlock player options";
			frame.displayMessageDialog(message);
			return;
		}

		//remove selected player if pre-conditions satisfied
		Player player = viewModel.getSelectedPlayer();
		message = "Remove selected player?";
		int optionPaneOutcome = JOptionPane.showConfirmDialog(frame, message);
		if (optionPaneOutcome == JOptionPane.YES_OPTION)
		{
			gameEngine.removePlayer(player);
			viewModel.playerRemoved(player);
		}
			
	}

}
