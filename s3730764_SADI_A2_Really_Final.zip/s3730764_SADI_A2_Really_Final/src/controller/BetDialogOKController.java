package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import model.interfaces.GameEngine;
import model.interfaces.Player;
import view.BetDialogBox;
import view.MainFrame;
import view.model.ViewModel;

//Listens to the OK button on the BetDialogBox.
public class BetDialogOKController implements ActionListener
{
	private MainFrame frame;
	private BetDialogBox dialog;
	private GameEngine gameEngine;
	private ViewModel viewModel;
	
	public BetDialogOKController(MainFrame frame, BetDialogBox dialog, 
			GameEngine gameEngine, ViewModel viewModel)
	{
		this.frame = frame;
		this.dialog = dialog;
		this.gameEngine = gameEngine;
		this.viewModel = viewModel;
	}

	@Override
	public void actionPerformed(ActionEvent event) 
	{
		int bet = dialog.getBet();
		Player player = viewModel.getSelectedPlayer();
		
		if (player == null)
		{
			String message = "No player selected. Bet not placed.";
			frame.displayMessageDialog(message);
		}

		if (player != null)
			gameEngine.placeBet(player, bet);
		
		if (player.getBet() > 0)
			viewModel.betPlaced(player, bet);
		
		dialog.dispose();
			
	}

}
