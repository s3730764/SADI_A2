package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import model.file.GameLoader;
import model.interfaces.GameEngine;
import view.AddPlayerDialogBox;
import view.MainFrame;
import view.model.ViewModel;

//Listens to the Add Player button and menu item. Creates AddPlayerDialogBox
public class AddPlayerController implements ActionListener
{
	private GameEngine gameEngine;
	private MainFrame frame;
	private GameLoader gameLoader;
	private ViewModel viewModel;
	
	public AddPlayerController(GameEngine gameEngine, MainFrame frame, 
			GameLoader gameLoader, ViewModel viewModel)
	{
		this.gameEngine = gameEngine;
		this.frame = frame;
		this.gameLoader = gameLoader;
		this.viewModel = viewModel;
	}

	@Override
	public void actionPerformed(ActionEvent event) 
	{	
		//Prevent players being added at the end of the game
		int numOfPlayers = gameEngine.getAllPlayers().size();
		String message = "Players cannot be added at the end of the game.\n"
				+ "Select 'New Game' to unlock player options";
		
		if (numOfPlayers > 0 && viewModel.allPlayersPlayed())
		{
			frame.displayMessageDialog(message);
			return;
		}
		
		//Dialog box to get player details
		new AddPlayerDialogBox(frame, gameEngine, gameLoader, viewModel);
	}

}
