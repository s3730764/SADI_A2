package client;


import java.util.Collection;

import javax.swing.SwingUtilities;

import model.GameEngineImpl;
import model.file.GameLoader;
import model.file.GameLoaderException;
import model.file.GameLoaderImpl;
import model.interfaces.GameEngine;
import model.interfaces.Player;
import validate.Validator;
import view.MainFrame;
import view.GameEngineCallbackImpl;

public class MyGUIClient 
{

	public static void main(String[] args) throws GameLoaderException 
	{
		Validator.validate(false);

		GameEngine gameEngine = new GameEngineImpl();
		gameEngine.addGameEngineCallback(new GameEngineCallbackImpl());
		
		//Load saved player details
		String path = "backup.txt";
		GameLoader gameLoader = new GameLoaderImpl(path);
		Collection<Player> players = gameLoader.loadAllPlayers(path);
		for (Player player : players)
			gameEngine.addPlayer(player);
				
				
		SwingUtilities.invokeLater(new Runnable() 
		{
			@Override
			public void run()
			{
				MainFrame frame = new MainFrame(gameEngine, gameLoader);
			}
		});
				

	}

}
