package model.file;

import java.util.Collection;

import model.interfaces.Player;

public abstract class AbstractGameLoader implements GameLoader
{
	private String path;
	
	public AbstractGameLoader(String path) 
	{
		this.path = path;
	}
	
	@Override
	public String getPath() 
	{
		return path;
	}

	@Override
	public abstract Collection<Player> loadAllPlayers(String path) throws GameLoaderException; 


	@Override
	public abstract void saveAllPlayers(String path, Collection<Player> players) throws GameLoaderException; 


	@Override
	public abstract void appendPlayer(String path, Player player) throws GameLoaderException; 


}
