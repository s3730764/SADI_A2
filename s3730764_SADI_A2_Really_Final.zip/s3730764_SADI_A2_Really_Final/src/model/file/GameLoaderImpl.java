package model.file;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Scanner;
import java.util.StringTokenizer;

import model.interfaces.Player;
import view.model.PlayerView;

//Loads, updates and saves players and their points for future executions of the program
public class GameLoaderImpl extends AbstractGameLoader
{
	private 	Scanner scanner = null;
	private PrintStream printStream;
	private 	Collection<Player> players = new ArrayList<Player>();

	public GameLoaderImpl(String path)
	{
		super(path);
	}
	
	
	@Override
	public Collection<Player> loadAllPlayers(String path) throws GameLoaderException 
	{		
		try 
		{
			scanner = new Scanner(new FileInputStream(path));
		} 
		catch (FileNotFoundException e) 
		{
			e.printStackTrace();
		}

		while(scanner.hasNextLine())
		{
			StringTokenizer tokenizer = new StringTokenizer(scanner.nextLine(), ":");
			if (tokenizer.countTokens() != 3)
				throw new GameLoaderException("Corrupted input data");
			
			String id = tokenizer.nextToken();
			String name = tokenizer.nextToken();
			int points = Integer.parseInt(tokenizer.nextToken());
			
			Player player = new PlayerView(id, name, points);
			players.add(player);
		}
		
		scanner.close();
		return players;
	}

	@Override
	public void saveAllPlayers(String path, Collection<Player> players) throws GameLoaderException 
	{
		try
		{
			printStream = new PrintStream(new FileOutputStream(path));
			for (Player player : players)
			{
				String id = player.getPlayerId();
				String name = player.getPlayerName();
				int points = player.getPoints();
				printStream.printf("%s:%s:%s\n", id, name, points);
			}
		}
		catch (FileNotFoundException e)
		{
			e.printStackTrace();
		}
			
	}

	@Override
	public void appendPlayer(String path, Player player) throws GameLoaderException 
	{
		players.add(player);
		saveAllPlayers(path, players);
	}

}
