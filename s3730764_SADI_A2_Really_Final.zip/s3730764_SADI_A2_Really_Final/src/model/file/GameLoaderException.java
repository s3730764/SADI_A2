package model.file;

public class GameLoaderException extends Exception 
{
	public GameLoaderException()
	{
		super("Backup error");
	}
	
	public GameLoaderException(String message)
	{
		super(message);
	}

}
