package model;

import java.util.Collection;
import java.util.Collections;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Map;

import model.interfaces.GameEngine;
import model.interfaces.Player;
import model.interfaces.PlayingCard;
import view.interfaces.GameEngineCallback;

public class GameEngineImpl implements GameEngine 
{
		
	private Map<String, Player> players;
	private Collection<GameEngineCallback> gameEngineCallbacks;
	private Deque<PlayingCard> deck;
	
	
	public GameEngineImpl()
	{
		players = new HashMap<String, Player>();
		gameEngineCallbacks = new HashSet<GameEngineCallback>();
		deck = getShuffledDeck();
	}
	
	
	@Override
	public void dealPlayer(Player player, int delay) 	
	{
		int result = deal(player, delay);
		
		player.setResult(result);
		
		for (GameEngineCallback callback : gameEngineCallbacks) 
			callback.result(player, result, this);		
	}
	
	@Override
	public void dealHouse(int delay) 
	{	
		int houseResult = deal(null, delay);
		
		for (Player player : players.values())
			determineOutcome(player, houseResult);
		
		for (GameEngineCallback callback : gameEngineCallbacks) 
			callback.houseResult(houseResult, this);		
	}
		
	
	private int deal(Player player, int delay)
	{
		int result = 0;
		int cardTotal = 0;
		PlayingCard card = null;;
		
		while (cardTotal < GameEngine.BUST_LEVEL) 
		{
			card = nextCard(player, delay, cardTotal);
			cardTotal += card.getScore();
			result = cardTotal <= GameEngine.BUST_LEVEL ? cardTotal : result;
		}
		return result;
	}


	private PlayingCard nextCard(Player player, int delay, int cardsTotal) 
	{
		PlayingCard card = deck.removeLast();
		PlayingCard bustCard = 
				card.getScore() + cardsTotal > GameEngine.BUST_LEVEL ?
				card : null;
				
		delay(delay);

		for (GameEngineCallback callback : gameEngineCallbacks)
			if (bustCard == null && player != null)
				callback.nextCard(player, card, this);
			else if (bustCard == null && player == null)
				callback.nextHouseCard(card, this);
			else if (player != null)
				callback.bustCard(player, bustCard, this);
			else
				callback.houseBustCard(bustCard, this);
		
		if (deck.size() == 0)
			deck = getShuffledDeck();
		
		return card;
	}


	private void delay(int delay) 
	{
		try 
		{
			Thread.sleep(delay);
		}
		catch (InterruptedException e) 
		{
			return;
		}		
	}


	private void determineOutcome(Player player, int houseResult) 
	{
		if (player.getResult() == houseResult)
			return;
		else if (player.getResult() > houseResult)
			player.setPoints(player.getBet());
		else
			player.setPoints(-player.getBet());	
		player.resetBet();
	}


	@Override 
	public void addPlayer(Player player) 
	{
		players.put(player.getPlayerId(), player);
	}

	
	@Override
	public Player getPlayer(String id) 
	{
		return players.get(id);
	}

	
	@Override
	public boolean removePlayer(Player player) 
	{
		return players.remove(player.getPlayerId(), player);
	}

	
	@Override
	public void addGameEngineCallback(GameEngineCallback gameEngineCallback) 
	{
		gameEngineCallbacks.add(gameEngineCallback);
	}

	
	@Override
	public boolean removeGameEngineCallback(GameEngineCallback gameEngineCallback) 
	{
		return gameEngineCallbacks.remove(gameEngineCallback);
	}

	
	@Override
	public Collection<Player> getAllPlayers() 
	{
		return Collections.unmodifiableCollection(players.values());
	}

	
	@Override
	public boolean placeBet(Player player, int bet) 
	{
		return player.placeBet(bet);
	}

	
	//Returns a shuffled deck of 52 unique cards.
	//Does NOT return the actual deck.
	public Deque<PlayingCard> getShuffledDeck() 
	{
		return shuffleDeck(newDeck());
	}
	
	
	private Deque<PlayingCard> newDeck() 
	{	
		Deque<PlayingCard> newDeck = new LinkedList<PlayingCard>();
		for (PlayingCard.Suit suit : PlayingCard.Suit.values())
			for (PlayingCard.Value value : PlayingCard.Value.values())
				newDeck.add(new PlayingCardImpl(suit, value));
		return newDeck;
	}
	
	
	private Deque<PlayingCard> shuffleDeck(Deque<PlayingCard> deck) 
	{
		LinkedList<PlayingCard> shuffleList = new LinkedList<PlayingCard>();
		shuffleList.addAll(deck);
		Collections.shuffle(shuffleList);
		deck = shuffleList;
		return deck;
	}
}
