package model;

import model.interfaces.Player;

public class SimplePlayer implements Player 
{
	
	private String playerId;
	private String playerName;
	private int points;
	private int bet;
	private int result;

	public SimplePlayer (String playerId, String playerName, int initialPoints)
	{
		this.playerId = playerId;
		this.playerName = playerName;
		this.points = initialPoints;
	}
	

	@Override
	public String getPlayerName() 
	{
		return playerName;
	}

	
	@Override
	public void setPlayerName(String playerName) 
	{
		this.playerName = playerName;
	}
	

	@Override
	public int getPoints() 
	{
		return points;
	}
	

	@Override
	public void setPoints(int points) 
	{
		this.points += points;
	}

	
	@Override
	public String getPlayerId() 
	{
		return playerId;
	}
	

	@Override
	public boolean placeBet(int bet) 
	{
		if (bet < 0 || bet > points)
				return false;
		this.bet = bet;
		return true;
	}
	

	@Override
	public int getBet() 
	{
		return bet;
	}
	

	@Override
	public void resetBet() 
	{
		bet = 0;
	}
	

	@Override
	public int getResult() 
	{
		return result;
	}
	

	@Override
	public void setResult(int result) 
	{
		this.result = result;
	}
	
	
	@Override
	public String toString() 
	{
		return String.format("Player: id=%s, name=%s, points=%s", 
				playerId, playerName, points);
	}

}
