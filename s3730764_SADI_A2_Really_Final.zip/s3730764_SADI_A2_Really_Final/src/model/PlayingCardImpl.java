package model;

import model.interfaces.PlayingCard;

public class PlayingCardImpl implements PlayingCard 
{
	
	private Suit suit;
	private Value value;
	
	
	public PlayingCardImpl(Suit suit, Value value) 
	{
		this.suit = suit;
		this.value = value;
	}
	

	@Override
	public Suit getSuit() 
	{
		return suit;
	}

	
	@Override
	public Value getValue() 
	{
		return value;
	}

	
	@Override
	public int getScore() 
	{
		if (value.ordinal() < 9)
			return value.ordinal() + 1;
		return 10;
	}
	
	
	@Override
	public String toString() 
	{
		return String.format("Suit: %s, Value: %s, Score: %d", 
				suit, value, getScore());
	}
	

	@Override
	public boolean equals(PlayingCard card) 
	{
		if (card == null)
			return false;
		return (this.value.equals(card.getValue()) 
				&& this.suit.equals(card.getSuit()));
	}
	
	
	@Override
	public int hashCode() 
	{
		final int prime = 31;
		int result = 1;
		result = prime * result + ((suit == null) ? 0 : suit.hashCode());
		result = prime * result + ((value == null) ? 0 : value.hashCode());
		return result;
	}
	

	@Override
	public boolean equals(Object obj) 
	{
		return equals((PlayingCard) obj);
	}

}
