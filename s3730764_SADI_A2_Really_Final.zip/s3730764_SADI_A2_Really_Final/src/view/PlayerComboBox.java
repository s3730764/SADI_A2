package view;

import java.util.Collection;

import model.interfaces.Player;
import view.adapters.AbstractJComboBoxAdapter;
import view.interfaces.ViewModelObserver;
import view.model.PlayerView;
import view.model.ViewModel;

public class PlayerComboBox extends AbstractJComboBoxAdapter implements ViewModelObserver
{
	private ViewModel viewModel;
	
	public PlayerComboBox(Collection<Player> players, ViewModel viewModel)
	{		
		this.viewModel = viewModel;
		viewModel.addObserver(this);
		
		if (players != null)
		{
			for (Player player : players)
			{
				PlayerView playerView = getPlayerView(player);
				addItem(playerView);
				if (viewModel.getSelectedPlayer() == null)
					viewModel.playerSelected(player);
			}		
		}
		
		setToolTipText("Select a player");
	
	}
	
	public PlayerView getPlayerView(Player player)
	{
		if (player instanceof PlayerView)
			return (PlayerView)player;
		
		return null;
	}
	
	@Override
	public void playerAdded(Player player)
	{
		addItem(getPlayerView(player));
		setSelectedItem(player);
	}
	
	@Override
	public void playerRemoved(Player player)
	{
		removeItem(getPlayerView(player));
	}
	
	@Override
	public void playerSelected(Player player)
	{
		setSelectedItem(getPlayerView(player));
	}
	
	@Override
	public void result(Player player, int result)
	{
		Player selectedPlayer = viewModel.getSelectedPlayer();
		if (!viewModel.allPlayersPlayed())
			setSelectedItem(getPlayerView(selectedPlayer));
	}
	
	@Override
	public void newGame()
	{
		boolean gameHasPlayers = getItemCount() > 0;
		if (gameHasPlayers)
			setSelectedIndex(0);
	}
	
}
