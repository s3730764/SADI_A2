package view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionListener;

import javax.swing.AbstractButton;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JToggleButton;

import model.interfaces.Player;
import model.interfaces.PlayingCard;
import view.adapters.AbstractJToolBarAdapter;
import view.interfaces.ViewModelObserver;
import view.model.ViewModel;

public class ToolBar extends AbstractJToolBarAdapter implements ViewModelObserver
{
	//Enables/disables buttons depending on the state of the selected player and game
	
	private ViewModel viewModel;
	private ActionListener[] controllers;
	private AbstractButton[] buttons;
	private final int addPlayerIndex = 1;
	private final int betIndex = 2;
	private final int dealIndex = 3;

	public ToolBar(ViewModel viewModel, ActionListener[] controllers, PlayerComboBox playerComboBox)
	{
		this.viewModel = viewModel;
		this.controllers = controllers;
		
		buttons = new AbstractButton[] {
				new JToggleButton("New Game"),
				new JToggleButton("Add Player"),
				new JToggleButton("Place Bet"),
				new JToggleButton("Deal"),
				};
		
		//Add components to toolBar and style
		add(playerComboBox);
		playerComboBox.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18));
		ButtonGroup buttonGroup = new ButtonGroup();
		for (AbstractButton button : buttons)
		{
			add(button);
			buttonGroup.add(button);
			button.setFont(new Font(Font.SANS_SERIF, Font.ITALIC, 16));
			button.setBorder(BorderFactory.createRaisedBevelBorder());
			button.setPreferredSize(new Dimension(150,30));
			button.setToolTipText(button.getText() + " for Selected Player");
			button.setForeground(Color.BLACK);
		}
		
		//Add listeners to toolbar components
		int selectIndex = dealIndex + 1;
		playerComboBox.addActionListener(controllers[selectIndex]);
		for (int index = 0; index < buttons.length; index++)
			buttons[index].addActionListener(controllers[index]);
				
		viewModel.addObserver(this);			
	}
	
	@Override
	public void newBet(Player player, int bet)
	{
		disableButton(betIndex, controllers[betIndex]);
	}
	
	@Override
	public void cardDealt(Player player, PlayingCard card)
	{	
		if (player == null)
			return;	
				
		//Disable buttons except New Game
		boolean playerHasCards = viewModel.getPreviousCards(player).size() > 0;
		if (!playerHasCards)
		{
			for (int index = addPlayerIndex; index < buttons.length; index++)
				disableButton(index, controllers[index]);
		}
	}

	
	@Override
	public void playerSelected(Player player)
	{	
		//Enable/disable relevant buttons depending on player's state
		boolean playerDealt = viewModel.getPreviousCards(player).size() > 0;
		
		if (playerDealt)
		{
			disableButton(betIndex, controllers[betIndex]);
			disableButton(dealIndex, controllers[dealIndex]);
		}
		
		else
		{
			enableButton(addPlayerIndex, controllers[addPlayerIndex]);
			enableButton(dealIndex, controllers[dealIndex]);
			if (player.getBet() > 0)
				disableButton(betIndex, controllers[betIndex]);
			else enableButton(betIndex, controllers[betIndex]);
		}
	}

	@Override
	public void newGame()
	{
		//Enable all the buttons
		for (int index = addPlayerIndex; index < buttons.length; index++)
			enableButton(index, controllers[index]);
	}

	private void disableButton(int index, ActionListener listener)
	{
		if (buttons[index].getActionListeners().length > 0)
		{
			buttons[index].setForeground(Color.LIGHT_GRAY);
			buttons[index].removeActionListener(listener);
		}
	}

	private void enableButton(int index, ActionListener listener)
	{
		if (buttons[index].getActionListeners().length == 0)
		{
			buttons[index].setForeground(Color.BLACK);
			buttons[index].addActionListener(listener);
		}
	}
}
