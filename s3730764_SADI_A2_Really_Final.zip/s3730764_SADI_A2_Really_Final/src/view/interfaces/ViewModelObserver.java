package view.interfaces;

import model.file.GameLoaderException;
import model.interfaces.Player;
import model.interfaces.PlayingCard;

public interface ViewModelObserver
{	
	/*Using this interface with component adapters allows components to be 
	ViewModelObservers whilst only implementing the methods they need.*/
	
	void playerAdded(Player player) throws GameLoaderException;
	
	void playerSelected(Player player);

	void newBet(Player player, int bet);
	
	void cardDealt(Player player, PlayingCard card);

	void result(Player player, int result);

	void playerRemoved(Player player);

	void newGame();
}
