package view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionListener;

import javax.swing.AbstractButton;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import controller.AddPlayerDialogOKController;
import controller.CancelButtonController;
import model.file.GameLoader;
import model.interfaces.GameEngine;
import model.interfaces.Player;
import view.model.PlayerView;
import view.model.ViewModel;

public class AddPlayerDialogBox extends JDialog
{
	//Dialog with multiple text fields to take in new player info in one go
	//Also has default points value for speed of use
	private JTextField nameField = new JTextField();
	private JTextField pointsField = new JTextField("1000");
	private final String okCommand = "OK";
	private static int autoId = 0;
	private MainFrame frame;
	private GameEngine gameEngine;
	
	public AddPlayerDialogBox(MainFrame frame, GameEngine gameEngine, 
			GameLoader gameLoader, ViewModel viewModel)
	{
		super(frame, true);
		this.frame = frame;
		this.gameEngine = gameEngine;
		setLayout(new BorderLayout());
		setTitle("Add Player");
		
		setAutoId();
			
		//Create panels to organise the text fields and buttons
		JPanel namePanel = new JPanel(new BorderLayout());
		JPanel pointsPanel = new JPanel(new BorderLayout());
		JPanel buttonPanel = new JPanel(new GridLayout(1,2));
		
		add(namePanel, BorderLayout.NORTH);
		add(pointsPanel, BorderLayout.CENTER);
		add(buttonPanel, BorderLayout.SOUTH);
		
		namePanel.add(new JLabel("Player's name: "), BorderLayout.WEST);
		namePanel.add(nameField, BorderLayout.EAST);
		nameField.setPreferredSize(new Dimension(100,25));
		
		pointsPanel.add(new JLabel("Player's initial points: "), BorderLayout.WEST);
		pointsPanel.add(pointsField, BorderLayout.EAST);
		pointsField.setPreferredSize(new Dimension(100,25));
		
		//create cancel and OK buttons
		AbstractButton ok = new JButton(okCommand);
		buttonPanel.add(ok);
		ActionListener okButtonController = new AddPlayerDialogOKController(
				this, gameEngine, gameLoader, viewModel);
		ok.addActionListener(okButtonController);
		
		AbstractButton cancel = new JButton("Cancel");
		buttonPanel.add(cancel);
		ActionListener cancelButtonController = new CancelButtonController(this);
		cancel.addActionListener(cancelButtonController);
		
		setSize(300,100);
		setLocationRelativeTo(frame);
		setVisible(true);
		
	}

	private void setAutoId() 
	{
		//Set autoId to 1 higher than highest current id
		for (Player player : gameEngine.getAllPlayers())
		{
			int playerId = Integer.parseInt(player.getPlayerId());
			if (autoId <= playerId)
				autoId = playerId + 1;		
		}
	}

	public Player getPlayer() 
	{
		int points = 1000;

		try 
		{
			points = Integer.parseInt(pointsField.getText());
		}
		catch(NumberFormatException e)
		{
			this.dispose();
			String defaultMessage = "Invalid entry. Default 1000 points allocated";
			frame.displayMessageDialog(defaultMessage);
		}
		
		Player player = new PlayerView(
				Integer.toString(autoId), 
				nameField.getText(), 
				points);
		setAutoId();
		return player;
	}

}
