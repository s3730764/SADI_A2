package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Label;
import java.util.ArrayList;
import java.util.Collection;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import model.interfaces.GameEngine;
import model.interfaces.Player;
import model.interfaces.PlayingCard;
import model.interfaces.PlayingCard.Suit;
import model.interfaces.PlayingCard.Value;
import view.adapters.AbstractJPanelAdapter;
import view.interfaces.ViewModelObserver;
import view.model.ImageView;
import view.model.ViewModel;

//cardPanel shows cards as they are being dealt
//cardList lists all cards dealt for the game to each player/House
//scoreUpdate updates the running score for each player as cards are being dealt

public class MainDisplay extends AbstractJPanelAdapter implements ViewModelObserver
{			
	private ViewModel viewModel;
	private JPanel cardPanel = new JPanel();
	private JPanel cardList = new JPanel();
	private JLabel scoreUpdate = new JLabel("\n", Label.LEFT);
	private ArrayList<PlayingCard> currentCards;
	
	public MainDisplay(ViewModel viewModel) 
	{
		this.viewModel = viewModel;
		viewModel.addObserver(this);
		currentCards = new ArrayList<PlayingCard>();
		
		setLayout(new BorderLayout());
		cardPanel.setBackground(Color.GRAY);
		cardList.setBackground(Color.LIGHT_GRAY);
		cardList.setPreferredSize(new Dimension(280, 0));
		
		add(cardPanel, BorderLayout.CENTER);
		add(cardList, BorderLayout.WEST);
		add(scoreUpdate, BorderLayout.SOUTH);
		
		cardPanel.add(new ImageView());
	}
	
	@Override
	public void playerSelected(Player player)
	{		
		//If player has been dealt, show previous cards
		Collection<PlayingCard> hand = viewModel.getPreviousCards(player);
		if (!hand.isEmpty())
			switchView(player);
	}

	private void switchView(Player player) 
	{
		//Display previous cards of player who has been dealt
		redrawPanel(cardPanel);
	
		ArrayList<PlayingCard> playerPreviousCards = viewModel.getPreviousCards(player);
		for (PlayingCard previousCard : playerPreviousCards)
			cardPanel.add(new ImageView(previousCard));
		
		scoreUpdate.setText("Showing previous cards for " + player.getPlayerName() + "...");		
		
	}

	@Override
	public void cardDealt(Player player, PlayingCard newCard) 
	{
		//Update card list and score as cards are being dealt
		String name;
		if (player == null)
		{
			name = "The House";
			cardPanel.setBackground(Color.RED);
		}
		else
		{
			name = player.getPlayerName();
			cardPanel.setBackground(Color.GRAY);
		}
		
		cardList.setLayout(new GridLayout(20,1));

		JLabel cardSummary;
		int totalScore = newCard.getScore();
		
		for (PlayingCard dealtCard : currentCards)
			totalScore += dealtCard.getScore();
		
		Value cardValue = newCard.getValue();
		Suit suit = newCard.getSuit();
		if (totalScore > GameEngine.BUST_LEVEL)
		{
			String text = name + ": " + cardValue + " of " + suit + " - BUST!";
			int validScore = totalScore - newCard.getScore();
			cardSummary = new JLabel(text);
			scoreUpdate.setText(name + " busted! Final score: " + validScore);
		}
		else 
		{
			String text = name + ": " + cardValue + " of " + suit;
			cardSummary = new JLabel(text);
			scoreUpdate.setText("Score for " + name + ": " + totalScore);
		}
		
		cardSummary.setPreferredSize(new Dimension(250,0));
		cardList.add(cardSummary);
		scoreUpdate.setBackground(Color.WHITE);
		
		Player selectedPlayer = viewModel.getSelectedPlayer();
		
		//If selectedPlayer has already been dealt, show previous cards
		if (selectedPlayer != null) //|| currentCards.size() > 1)
			if (!selectedPlayer.equals(player))
			{
				switchView(selectedPlayer);
				currentCards.add(newCard);			
				return;
			}
			
		
		//Otherwise show cards as they're being dealt
		redrawPanel(cardPanel);
		
		for (PlayingCard dealCard : currentCards)
			cardPanel.add(new ImageView(dealCard));
		
		cardPanel.add(new ImageView(newCard));
		currentCards.add(newCard);			

	}

	@Override
	public void result(Player player, int result) 
	{
		currentCards.clear();
		
		//After House result, update scores
		if (player == null)
		{
			scoreUpdate.setLayout(new FlowLayout());
			for (Component component : scoreUpdate.getComponents())
				component.invalidate();
			scoreUpdate.validate();
			
			showGameResults(player, result);
		}
	}

	private void showGameResults(Player player, int result) 
	{
		//Creates a JOptionPane with the game summary
		String playerResults = "";
		for (Player storedPlayer : viewModel.getPlayerArrayList())
		{
			String storedPlayerName = storedPlayer.getPlayerName();
			int storedPlayerResult = storedPlayer.getResult();
			playerResults += "\n" + storedPlayerName + " final score:\t" + storedPlayerResult;
		}
		playerResults += "\nThe House final score:\t" + result;
		String newGame = String.format("Game Completed!\n%s", playerResults);
		JOptionPane.showMessageDialog(this, newGame);
	}

	@Override
	public void newGame() 
	{
		redrawPanel(cardList);
		redrawPanel(cardPanel);

		cardPanel.add(new ImageView());
		cardPanel.setBackground(Color.GRAY);
		
		scoreUpdate.setText("\n");
	}
	
	private void redrawPanel(JPanel panel)
	{
		panel.setLayout(new FlowLayout());
		for (Component component : panel.getComponents())
		{
			component.invalidate();
			component.setVisible(false);
		}
		panel.removeAll();
		panel.validate();
	}
	
	


}
