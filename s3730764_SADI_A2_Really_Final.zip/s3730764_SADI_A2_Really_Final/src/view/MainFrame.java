package view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionListener;
import java.util.Collection;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import controller.DealPlayerController;
import controller.NewGameController;
import controller.AddPlayerController;
import controller.BetController;
import controller.SelectPlayerController;
import controller.QuitController;
import controller.RemovePlayerController;
import model.file.GameLoader;
import model.interfaces.GameEngine;
import model.interfaces.Player;
import view.interfaces.GameEngineCallback;
import view.model.ViewModel;
import view.model.ViewModelImpl;

//Creates main components of the GUI, holds non-observer items such as menu items
//Creates ViewModel to be passed to components
public class MainFrame extends JFrame
{  
	private GameEngine gameEngine;
	private ViewModel viewModel;

	public MainFrame(GameEngine gameEngine, GameLoader gameLoader) 
	{
		super("Black Jack");
		setLayout(new BorderLayout());		
		
		this.gameEngine = gameEngine;
		
		viewModel = new ViewModelImpl(gameEngine);
		Collection<Player> players = gameEngine.getAllPlayers();
		
		//Create GECGUI and add to gameEngine
		GameEngineCallback gameEngineCallbackGUI = new GameEngineCallbackGUI(viewModel);
		gameEngine.addGameEngineCallback(gameEngineCallbackGUI);
		
		//Instantiate fields that need viewModel
		MainDisplay mainDisplayPanel = new MainDisplay(viewModel); 
		StatusBar statusBar = new StatusBar(viewModel);
		PlayerComboBox playerComboBox = new PlayerComboBox(players, viewModel);
		ActionListener selectPlayerController = new SelectPlayerController(playerComboBox, viewModel);
		PlayerMenu playerMenu = new PlayerMenu("SelectPlayer", viewModel, selectPlayerController);
		
		//Create action listeners to be added to menu/buttons
		ActionListener[] controllers = new ActionListener[] {
				new NewGameController(viewModel, this),
				new AddPlayerController(gameEngine, this, gameLoader, viewModel),
				new BetController(this, viewModel, gameLoader),
				new DealPlayerController(viewModel, gameEngine, this, gameLoader),
				selectPlayerController,
				new RemovePlayerController(gameEngine, viewModel, this),
				new QuitController(gameLoader, gameEngine, this)
		};
						
		//add components to frame and menuBar
		JMenuBar menuBar = new JMenuBar();
		JMenu menu = new JMenu("Menu");
		menuBar.add(menu);
		setJMenuBar(menuBar);
		ToolBar toolBar = new ToolBar(viewModel, controllers, playerComboBox);
		add(toolBar, BorderLayout.NORTH);
		add(mainDisplayPanel, BorderLayout.CENTER);
		add(statusBar, BorderLayout.SOUTH);
		
		//Set up menu
		JMenuItem[] menuItems = new JMenuItem[] {
				new JMenuItem("New Game"),
				new JMenuItem("Add Player"), 				
				new JMenuItem("Bet Selected Player"),
				new JMenuItem("Deal Selected Player"),
				playerMenu,
				new JMenuItem("Remove Player"),
				new JMenuItem("Quit")
				};
		
		for (JMenuItem menuItem : menuItems)
			menu.add(menuItem);
		
		//Add action listeners to menu items
		for (int index = 0; index < menuItems.length; index++)
			menuItems[index].addActionListener(controllers[index]);
		
		setBounds(100,100,1000,850);
		setVisible(true);
		addWindowListener(new QuitController(gameLoader, gameEngine, this));
		
		//Set minimum size
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		double width = screenSize.getWidth()/2.5;
		double height = screenSize.getHeight()/2.5;
		this.setMinimumSize(new Dimension((int)width, (int)height));
		
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
	}
	
	
	public void quit() 
	{
		String quitMessage = "Are you sure you wish to exit the game?";
		int optionPaneOutcome = JOptionPane.showConfirmDialog(this, quitMessage);
		if (optionPaneOutcome == JOptionPane.YES_OPTION)
			System.exit(0);
	}

	public void promptAddPlayerDialog(GameLoader gameLoader)
	{
		//If Bet or Deal button pressed when no player in the game
		String message = "There are no players in the game!\n"
				+ "Would you like to add a new player?";
		int optionPaneOutcome = JOptionPane.showConfirmDialog(this, message);
		
		if (optionPaneOutcome == JOptionPane.YES_OPTION)
			new AddPlayerDialogBox(this, gameEngine, gameLoader, viewModel);
	}


	public void displayBetDialog() 
	{	
		new BetDialogBox(this, gameEngine, viewModel);
	}


	public void displayMessageDialog(String message) 
	{
		JOptionPane.showMessageDialog(this, message);
	}


	public int displayConfirmDialog(String message) 
	{
		return JOptionPane.showConfirmDialog(this, message);
	}

	
}
