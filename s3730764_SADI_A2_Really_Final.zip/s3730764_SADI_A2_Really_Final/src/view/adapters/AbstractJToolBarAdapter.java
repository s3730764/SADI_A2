package view.adapters;

import javax.swing.JToolBar;

import model.file.GameLoaderException;
import model.interfaces.Player;
import model.interfaces.PlayingCard;
import view.interfaces.ViewModelObserver;

public class AbstractJToolBarAdapter extends JToolBar implements ViewModelObserver
{
	@Override
	public void playerAdded(Player player) throws GameLoaderException {}

	@Override
	public void playerSelected(Player player) {}

	@Override
	public void newBet(Player player, int bet) {}

	@Override
	public void cardDealt(Player player, PlayingCard card) {}

	@Override
	public void result(Player player, int result) {}

	@Override
	public void playerRemoved(Player player) {}

	@Override
	public void newGame() {}
}
