package view.model;

import java.util.ArrayList;

import model.file.GameLoaderException;
import model.interfaces.Player;
import model.interfaces.PlayingCard;
import view.interfaces.ViewModelObserver;

public interface ViewModel
{	
	void playerAdded(Player player) throws GameLoaderException;

	void playerSelected(Player player);
	
	void betPlaced(Player player, int bet);

	void addObserver(ViewModelObserver observer);
	
	Player getSelectedPlayer();

	void nextCard(Player player, PlayingCard card);

	void playerResult(Player player, int result);
	
	void houseResult(int result);
			
	boolean allPlayersPlayed();
	
	ArrayList<Player> getPlayerArrayList();

	ArrayList<PlayingCard> getPreviousCards(Player player);

	void playerRemoved(Player player);

	void newGame();

}
