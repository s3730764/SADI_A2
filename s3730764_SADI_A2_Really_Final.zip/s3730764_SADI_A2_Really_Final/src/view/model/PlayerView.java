package view.model;

import model.SimplePlayer;

//Enables combo box to show custom text
public class PlayerView extends SimplePlayer
{
	
	public PlayerView(String id, String name, int points)
	{
		super(id, name, points);
	}
	
	@Override
	public String toString()
	{
		return "Selected Player:\t\t" + super.getPlayerName();
	}
}
