package view.model;

import java.io.File;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

import model.interfaces.PlayingCard;

//Creates JLabel images from files
public class ImageView extends JLabel
{
	private ImageIcon icon;
	private String separator = File.separator;
		
	public ImageView(PlayingCard card)
	{
		icon = new ImageIcon("images" + separator + card.getSuit() + "-" + card.getValue() + ".png");
		setIcon(icon);
	}
	
	public ImageView()
	{
		//Used to set up initial game image
		icon = new ImageIcon("images" + separator + "blackjack.png");
		setIcon(icon);
	}


}
