package view.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import model.file.GameLoaderException;
import model.interfaces.GameEngine;
import model.interfaces.Player;
import model.interfaces.PlayingCard;
import view.interfaces.ViewModelObserver;

public class ViewModelImpl implements ViewModel
{
	private GameEngine gameEngine;
	private Collection<ViewModelObserver> observers;
	private Player selectedPlayer;
	private Map<String, ArrayList<PlayingCard>> previousCards;


	public ViewModelImpl(GameEngine gameEngine)
	{
		this.gameEngine = gameEngine;
		
		observers = new ArrayList<ViewModelObserver>();
		previousCards = new HashMap<String, ArrayList<PlayingCard>>();
		
		Collection<Player> players = gameEngine.getAllPlayers();
		for (Player player : players)
		{
			//Select first player if any loaded from GameLoader
			selectedPlayer = selectedPlayer == null ? player : null;
			previousCards.put(player.getPlayerId(), new ArrayList<PlayingCard>());
		}
	}
	
	
	@Override
	public void playerAdded(Player player) throws GameLoaderException 
	{	
		//Add new player to previous cards with empty hand
		previousCards.put(player.getPlayerId(), new ArrayList<PlayingCard>());
		
		//Select new player
		playerSelected(player);
		
		for (ViewModelObserver observer : observers)
			observer.playerAdded(player);
	}

	@Override
	public void playerRemoved(Player player) 
	{
		previousCards.remove(player.getPlayerId());
		
		selectNextPlayer();
		
		for (ViewModelObserver observer : observers)
			observer.playerRemoved(player);
	}


	@Override
	public void playerSelected(Player player) 
	{	
		int numOfPlayers = gameEngine.getAllPlayers().size();
		
		if (numOfPlayers == 0) return;
		
		selectedPlayer = player;
		
		for (ViewModelObserver observer: observers)
			observer.playerSelected(player);		
	
	}

	@Override
	public Player getSelectedPlayer() 
	{	
		return selectedPlayer;
	}


	@Override
	public void betPlaced(Player player, int bet) 
	{
		for (ViewModelObserver observer : observers)
			observer.newBet(player, bet);
	}

	@Override
	public void nextCard(Player player, PlayingCard card) 
	{	
		for (ViewModelObserver observer : observers)
			observer.cardDealt(player, card);
		
		Collection<PlayingCard> hand;
		
		//Add card to previous cards
		if (player != null)
		{
			hand = previousCards.get(player.getPlayerId());
			hand.add(card);
		}

	}


	@Override
	public void playerResult(Player player, int result) 
	{		
		if (allPlayersPlayed()) 
			selectedPlayer = null;
		else selectNextPlayer();


		for (ViewModelObserver observer : observers)
			observer.result(player, result);
	}


	@Override
	public void houseResult(int result) 
	{
		for (ViewModelObserver observer : observers)
			observer.result(null, result);		
	}

	@Override
	public void newGame() 
	{
		int numOfPlayers = getPlayerArrayList().size();
		
		if (numOfPlayers > 0)
		{
			for (Player player : getPlayerArrayList())
				player.setResult(0);
			
			//Reset previous cards
			for (String playerId : previousCards.keySet())
				previousCards.put(playerId, new ArrayList<PlayingCard>());
			
			//Selects the player with the lowest id number
			int comparison = Integer.MAX_VALUE;
			
			for (Player player : gameEngine.getAllPlayers())
			{
				int playerId = Integer.parseInt(player.getPlayerId());		
				if (playerId < comparison)
				{
					comparison = playerId;
					selectedPlayer = player;
				}
			}
		}
		
		for (ViewModelObserver observer : observers)
			observer.newGame();		
	}

	@Override
	public void addObserver(ViewModelObserver observer) 
	{
		observers.add(observer);
	}
	
	@Override
	public boolean allPlayersPlayed()
	{
		for (Collection<PlayingCard> hand : previousCards.values())
			if (hand.isEmpty())
				return false;
		
		return true;
	}
	
	//Returns an ArrayList of all players rather than a Collection
	@Override
	public ArrayList<Player> getPlayerArrayList() 
	{
		ArrayList<Player> players = new ArrayList<Player>();
		for (Player player : gameEngine.getAllPlayers())
			players.add(player);
		return players;
	}
	

	@Override
	public ArrayList<PlayingCard> getPreviousCards(Player player) 
	{
		return previousCards.get(player.getPlayerId());
	}


	private void selectNextPlayer() 
	{
		//Auto select next player for speed of use
		if (!allPlayersPlayed())
		{
			String nextPlayerId = null;
			Player nextPlayer = null;
			
			for (String id : previousCards.keySet())
			{
				Collection<PlayingCard> hand = previousCards.get(id);
				nextPlayerId = hand.isEmpty() ? id : null;
				if (nextPlayerId != null)
				{
					for (Player player : gameEngine.getAllPlayers())
					{
						boolean playerIsNext = player.getPlayerId().equals(id);
						nextPlayer = playerIsNext ? player : null;
						selectedPlayer = nextPlayer != null ? nextPlayer : selectedPlayer;
					}
					
					break;
				}
			}
			
			boolean playerHasPlayed = previousCards.get(selectedPlayer.getPlayerId()).size() > 0;
			
			if (!playerHasPlayed)
				for (ViewModelObserver observer : observers)
					observer.playerSelected(selectedPlayer);	
		}		
	}

}
