package view;

import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JMenuItem;

import model.interfaces.Player;
import view.adapters.AbstractJMenuAdapter;
import view.interfaces.ViewModelObserver;
import view.model.ViewModel;

//Menu within the main menu to allow players to be selected -- alternative to combo box
public class PlayerMenu extends AbstractJMenuAdapter implements ViewModelObserver
{
	private ArrayList<JMenuItem> playerMenuItems = new ArrayList<JMenuItem>();
	private ActionListener selectPlayerController;


	public PlayerMenu(String text, ViewModel viewModel, ActionListener selectPlayerController) 
	{
		super(text);	
		this.selectPlayerController = selectPlayerController;
		
		viewModel.addObserver(this);
		
		for (Player player : viewModel.getPlayerArrayList())
			addPlayerMenuItem(player);
		
		for (JMenuItem item : playerMenuItems)
		{
			add(item);
			item.addActionListener(selectPlayerController);
		}
	}


	private void addPlayerMenuItem(Player player) 
	{
		playerMenuItems.add(new JMenuItem(player.getPlayerName()));
	}
	
	@Override
	public void playerAdded(Player player)
	{	
		JMenuItem menuItem = new JMenuItem(player.getPlayerName());
		add(menuItem);
		playerMenuItems.add(menuItem);
		menuItem.addActionListener(selectPlayerController);	
	}
	
	@Override
	public void playerRemoved(Player player) 
	{	
		JMenuItem menuItem = null;
		for (JMenuItem item : playerMenuItems)
		{
			String itemText = item.getText();
			String playerName = player.getPlayerName();
			menuItem = itemText.equals(playerName) ? item : null;
			if (menuItem != null) break;
		}
		playerMenuItems.remove(menuItem);
		remove(menuItem);
	}
	
	
}
