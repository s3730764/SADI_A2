package view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Label;
import java.util.ArrayList;

import javax.swing.JLabel;
import javax.swing.JPanel;

import model.interfaces.Player;
import model.interfaces.PlayingCard;
import view.adapters.AbstractJPanelAdapter;
import view.interfaces.ViewModelObserver;
import view.model.ViewModel;

//summaryPanel maintains one summaryLabel per player to show player points, score when dealt
//statusLabel continuously updates cards dealt and player selected, added or removed
public class StatusBar extends AbstractJPanelAdapter implements ViewModelObserver
{
	private ViewModel viewModel;
	private JLabel statusLabel = new JLabel("", Label.LEFT);
	private JPanel summaryPanel = new JPanel(new GridLayout(2, 1));
	private ArrayList<Label> summaryLabels = new ArrayList<Label>();
	private final String houseName = "The House"; 

	
	public StatusBar(ViewModel viewModel)
	{	
		this.viewModel = viewModel;
		viewModel.addObserver(this);
		
		setLayout(new BorderLayout());
		this.setPreferredSize(new Dimension(0, 100));
		
		add(statusLabel, BorderLayout.NORTH);
		add(summaryPanel, BorderLayout.SOUTH);
		for (Player player : viewModel.getPlayerArrayList())
			playerAdded(player);
		
		statusLabel.setText("Black Jack");
		statusLabel.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18));
	}

	@Override
	public void playerAdded(Player player) 
	{
		Label newLabel = new Label(getSummaryText(player), Label.CENTER);
		summaryPanel.add(newLabel);	
		summaryLabels.add(newLabel);
		statusLabel.setText(player.getPlayerName() + " has been added to the game");
	}
	
	@Override
	public void playerRemoved(Player player) 
	{
		int lastLabel = summaryLabels.size()-1;
		summaryPanel.remove(lastLabel);
		summaryLabels.remove(lastLabel);
		updateSummaryPanel();
		statusLabel.setText(player.getPlayerName() + " has been removed from the game");
	}

	@Override
	public void playerSelected(Player player) 
	{
		if (player != null)
			statusLabel.setText(player.getPlayerName() + " selected");
	}

	@Override
	public void newBet(Player player, int bet) 
	{
		statusLabel.setText("Bet placed by " + player.getPlayerName() + ": " + bet);
	}

	@Override
	public void cardDealt(Player player, PlayingCard card) 
	{
		//Summarises the card dealt to the player
		String statusMessage = String.format("New card dealt to %s: the %s of %s", 
				player != null ? player.getPlayerName() : houseName, 
				card.getValue().name(), 
				card.getSuit().name());
		
		statusLabel.setText(statusMessage);
	}

	@Override
	public void result(Player player, int result) 
	{
		//If all players have played, shows final result for player
		String statusMessage;
		if (viewModel.allPlayersPlayed())
			statusMessage = String.format("Final result for %s: %d.", 
					player != null ? player.getPlayerName() : houseName, result);
		
		//Also shows next player selected if any player is yet to play
		else
			statusMessage = String.format("Final result for %s: %d.\t\t%s selected", 
					player != null ? player.getPlayerName() : 
						houseName, result, viewModel.getSelectedPlayer().getPlayerName());
		
		statusLabel.setText(statusMessage);	
			
		updateSummaryPanel();
	}


	private String getSummaryText(Player player) 
	{	
		//Creates the string to be added to a summaryLabel (one per player)
		String message;
		int score = player.getResult();
		String playerName = player.getPlayerName();
		int points = player.getPoints();
		
		if (score > 0)
			message = String.format("%s:\t\t%d Points\t\tScore:\t%d\n", playerName, points, score);
		else
			message = String.format("%s:\t\t%d Points\n", playerName, points);
		
		return message;
	}


	private void updateSummaryPanel()
	{	
		int numOfPlayers = viewModel.getPlayerArrayList().size();
		
		//Set text for each label
		for (int a = 0; a < numOfPlayers; a++)
		{
			Player player = viewModel.getPlayerArrayList().get(a);
			
			//Get the relevant summary label and set the text to the player's summary
			summaryLabels.get(a).setText(getSummaryText(player));
		}
	}

	@Override
	public void newGame() 
	{
		statusLabel.setText("New Game");
		
		updateSummaryPanel();
	}
}
