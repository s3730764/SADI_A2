package view;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionListener;

import javax.swing.AbstractButton;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import controller.BetDialogOKController;
import controller.CancelButtonController;
import model.interfaces.GameEngine;
import model.interfaces.Player;
import view.model.ViewModel;

public class BetDialogBox extends JDialog 
{
	//Dialog gives default value for bet for speed of use
	private JTextField betField = new JTextField("100");
	private final String okCommand = "OK";
	private MainFrame frame;
	private ViewModel viewModel;
	
	public BetDialogBox(MainFrame frame, GameEngine gameEngine, ViewModel viewModel) 
	{
		super(frame, true);
		this.viewModel = viewModel;
		setLayout(new BorderLayout());
		setTitle("Place Bet");
		
		JPanel textPanel = new JPanel(new GridLayout(1,2));
		JPanel buttonPanel = new JPanel(new GridLayout(1,2));
		
		add(textPanel, BorderLayout.CENTER);
		add(buttonPanel, BorderLayout.SOUTH);
		
		textPanel.add(new JLabel("Enter bet: "));
		textPanel.add(betField);
		
		AbstractButton ok = new JButton(okCommand);
		buttonPanel.add(ok);
		ActionListener okButtonController = new BetDialogOKController(
				frame, this, gameEngine, viewModel);
		ok.addActionListener(okButtonController);
		
		AbstractButton cancel = new JButton("Cancel");
		buttonPanel.add(cancel);
		ActionListener cancelButtonController = new CancelButtonController(this);
		cancel.addActionListener(cancelButtonController);
		
		setSize(250,100);
		setLocationRelativeTo(frame);
		setVisible(true);
	}

	public int getBet() 
	{
		int bet = 0;
		try 
		{
			bet = Integer.parseInt(betField.getText());
			while (bet < 1)
			{
				this.dispose();
				String message = "Invalid bet. Enter bet greater than 0.";
				bet = Integer.parseInt(JOptionPane.showInputDialog(frame, message));
			}	
		}
		catch(NumberFormatException e)
		{
			this.dispose();
			String message = "Invalid bet. Must be numbers only";
			JOptionPane.showMessageDialog(frame, message);			
		}
		
		Player player = viewModel.getSelectedPlayer();
		if (bet > player.getPoints())
		{
			this.dispose();
			String message = player.getPlayerName() + " does not have that many points to bet!";
			JOptionPane.showMessageDialog(frame, message);
		}
		
		return bet;
	}

}
