package view;

import model.interfaces.GameEngine;
import model.interfaces.Player;
import model.interfaces.PlayingCard;
import view.interfaces.GameEngineCallback;
import view.model.ViewModel;


public class GameEngineCallbackGUI implements GameEngineCallback 
{	
	private ViewModel viewModel;
	
	public GameEngineCallbackGUI(ViewModel viewModel)
	{
		this.viewModel = viewModel;
	}
	

	@Override
	public void nextCard(Player player, PlayingCard card, GameEngine engine) 
	{
		viewModel.nextCard(player, card);	
	}


	@Override
	public void bustCard(Player player, PlayingCard card, GameEngine engine) 
	{
		viewModel.nextCard(player, card);
	}

	@Override
	public void result(Player player, int result, GameEngine engine) 
	{
		viewModel.playerResult(player, result);
	}

	@Override
	public void nextHouseCard(PlayingCard card, GameEngine engine) 
	{
		viewModel.nextCard(null, card);
	}

	@Override
	public void houseBustCard(PlayingCard card, GameEngine engine) 
	{
		viewModel.nextCard(null, card);
	}

	@Override
	public void houseResult(int result, GameEngine engine) 
	{
		viewModel.houseResult(result);
	}


}
